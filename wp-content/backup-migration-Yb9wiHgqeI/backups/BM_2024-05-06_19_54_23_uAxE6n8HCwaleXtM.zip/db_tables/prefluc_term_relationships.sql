/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_term_relationships`; */
/* PRE_TABLE_NAME: `1715025271_prefluc_term_relationships`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715025271_prefluc_term_relationships` ( `object_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_order` int(11) NOT NULL DEFAULT 0, PRIMARY KEY (`object_id`,`term_taxonomy_id`), KEY `term_taxonomy_id` (`term_taxonomy_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1715025271_prefluc_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES (1,1,0),(30,2,0),(31,2,0),(32,2,0),(33,3,0),(34,3,0),(37,3,0),(41,2,0),(42,2,0),(43,2,0),(44,4,0),(47,4,0),(50,4,0),(51,1,0),(53,5,0),(56,1,0),(60,1,0),(66,6,0),(81,1,0),(116,3,0);
