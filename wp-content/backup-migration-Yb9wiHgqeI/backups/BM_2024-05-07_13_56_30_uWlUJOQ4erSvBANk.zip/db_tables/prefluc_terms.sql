/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_terms`; */
/* PRE_TABLE_NAME: `1715090198_prefluc_terms`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715090198_prefluc_terms` ( `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `name` varchar(200) NOT NULL DEFAULT '', `slug` varchar(200) NOT NULL DEFAULT '', `term_group` bigint(10) NOT NULL DEFAULT 0, PRIMARY KEY (`term_id`), KEY `slug` (`slug`(191)), KEY `name` (`name`(191))) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1715090198_prefluc_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES (1,'Non classé','non-classe',0),(2,'menu principal','menu-principal',0),(3,'menu pied de page','menu-pied-de-page',0),(4,'container','container',0),(5,'section','section',0),(6,'page','page',0),(7,'vapeur','vapeur',0),(8,'porc','porc',0),(9,'crevette','crevette',0);
