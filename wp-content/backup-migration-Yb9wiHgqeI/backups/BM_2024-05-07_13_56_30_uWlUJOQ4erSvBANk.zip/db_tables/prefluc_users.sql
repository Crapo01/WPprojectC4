/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_users`; */
/* PRE_TABLE_NAME: `1715090198_prefluc_users`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715090198_prefluc_users` ( `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `user_login` varchar(60) NOT NULL DEFAULT '', `user_pass` varchar(255) NOT NULL DEFAULT '', `user_nicename` varchar(50) NOT NULL DEFAULT '', `user_email` varchar(100) NOT NULL DEFAULT '', `user_url` varchar(100) NOT NULL DEFAULT '', `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', `user_activation_key` varchar(255) NOT NULL DEFAULT '', `user_status` int(11) NOT NULL DEFAULT 0, `display_name` varchar(250) NOT NULL DEFAULT '', PRIMARY KEY (`ID`), KEY `user_login_key` (`user_login`), KEY `user_nicename` (`user_nicename`), KEY `user_email` (`user_email`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1715090198_prefluc_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES (1,'admin','$P$BvRGH1QyN7wVSEEVUaldz9e4mCwekg1','admin','petitcrapo@hotmail.com','http://localhost/dimsumaddict','2024-05-04 17:24:17','',0,'admin'),(2,'visiteur','$P$BXZiUb0NruoY9qx2bPrOy48KXMlFDX1','visiteur','vi@vi.vi','','2024-05-06 20:47:09','',0,'visiteur');
