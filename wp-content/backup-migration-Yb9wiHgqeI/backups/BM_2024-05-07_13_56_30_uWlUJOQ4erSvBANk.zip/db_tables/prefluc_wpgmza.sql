/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_wpgmza`; */
/* PRE_TABLE_NAME: `1715090198_prefluc_wpgmza`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715090198_prefluc_wpgmza` ( `id` int(11) NOT NULL AUTO_INCREMENT, `map_id` int(11) NOT NULL, `address` varchar(700) NOT NULL, `description` mediumtext NOT NULL, `pic` varchar(700) NOT NULL, `link` varchar(2083) NOT NULL, `icon` varchar(700) NOT NULL, `lat` varchar(100) NOT NULL, `lng` varchar(100) NOT NULL, `anim` varchar(3) NOT NULL, `title` varchar(700) NOT NULL, `infoopen` varchar(3) NOT NULL, `category` varchar(500) NOT NULL, `approved` tinyint(1) DEFAULT 1, `retina` tinyint(1) DEFAULT 0, `type` tinyint(1) DEFAULT 0, `did` varchar(500) NOT NULL, `sticky` tinyint(1) DEFAULT 0, `other_data` longtext NOT NULL, `latlng` point DEFAULT NULL, `layergroup` int(3) DEFAULT 0, PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1715090198_prefluc_wpgmza` (`id`, `map_id`, `address`, `description`, `pic`, `link`, `icon`, `lat`, `lng`, `anim`, `title`, `infoopen`, `category`, `approved`, `retina`, `type`, `did`, `sticky`, `other_data`, `latlng`, `layergroup`) VALUES (1,1,'California','','','','',36.778261,-119.4179323999,'','','','',1,0,0,'',0,'','\0\0\0\0\0\0\0J`s�cB@�`�g��]�',0);
