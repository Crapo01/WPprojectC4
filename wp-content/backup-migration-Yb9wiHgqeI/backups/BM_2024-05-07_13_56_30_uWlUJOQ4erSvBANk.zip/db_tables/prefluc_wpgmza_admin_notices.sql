/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_wpgmza_admin_notices`; */
/* PRE_TABLE_NAME: `1715090198_prefluc_wpgmza_admin_notices`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715090198_prefluc_wpgmza_admin_notices` ( `id` int(11) NOT NULL AUTO_INCREMENT, `name` varchar(255) DEFAULT NULL, `message` text DEFAULT NULL, `active_date` datetime DEFAULT NULL, `options` longtext DEFAULT NULL, `dismissed` tinyint(1) DEFAULT 1, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
