/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_wpgmza_circles`; */
/* PRE_TABLE_NAME: `1715090198_prefluc_wpgmza_circles`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715090198_prefluc_wpgmza_circles` ( `id` int(11) NOT NULL AUTO_INCREMENT, `map_id` int(11) NOT NULL, `name` text DEFAULT NULL, `center` point DEFAULT NULL, `radius` float DEFAULT NULL, `color` varchar(16) DEFAULT NULL, `opacity` float DEFAULT NULL, `lineColor` varchar(16) DEFAULT NULL, `lineOpacity` float DEFAULT 0, `description` text DEFAULT NULL, `hoverEnabled` tinyint(1) DEFAULT 0, `ohFillColor` varchar(16) DEFAULT NULL, `ohLineColor` varchar(16) DEFAULT NULL, `ohFillOpacity` float DEFAULT NULL, `ohLineOpacity` float DEFAULT NULL, `link` varchar(700) NOT NULL, `layergroup` int(3) DEFAULT 0, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
