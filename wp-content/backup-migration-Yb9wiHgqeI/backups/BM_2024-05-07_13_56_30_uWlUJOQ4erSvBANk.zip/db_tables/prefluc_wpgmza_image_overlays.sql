/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_wpgmza_image_overlays`; */
/* PRE_TABLE_NAME: `1715090198_prefluc_wpgmza_image_overlays`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715090198_prefluc_wpgmza_image_overlays` ( `id` int(11) NOT NULL AUTO_INCREMENT, `map_id` int(11) NOT NULL, `name` text DEFAULT NULL, `cornerA` point DEFAULT NULL, `cornerB` point DEFAULT NULL, `image` varchar(700) DEFAULT NULL, `opacity` float DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
