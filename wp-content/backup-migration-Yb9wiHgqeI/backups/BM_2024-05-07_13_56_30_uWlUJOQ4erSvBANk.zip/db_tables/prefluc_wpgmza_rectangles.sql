/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_wpgmza_rectangles`; */
/* PRE_TABLE_NAME: `1715090198_prefluc_wpgmza_rectangles`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715090198_prefluc_wpgmza_rectangles` ( `id` int(11) NOT NULL AUTO_INCREMENT, `map_id` int(11) NOT NULL, `name` text DEFAULT NULL, `cornerA` point DEFAULT NULL, `cornerB` point DEFAULT NULL, `color` varchar(16) DEFAULT NULL, `opacity` float DEFAULT NULL, `lineColor` varchar(16) DEFAULT NULL, `lineOpacity` float DEFAULT 0, `description` text DEFAULT NULL, `hoverEnabled` tinyint(1) DEFAULT 0, `ohFillColor` varchar(16) DEFAULT NULL, `ohLineColor` varchar(16) DEFAULT NULL, `ohFillOpacity` float DEFAULT NULL, `ohLineOpacity` float DEFAULT NULL, `link` varchar(700) NOT NULL, `layergroup` int(3) DEFAULT 0, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
