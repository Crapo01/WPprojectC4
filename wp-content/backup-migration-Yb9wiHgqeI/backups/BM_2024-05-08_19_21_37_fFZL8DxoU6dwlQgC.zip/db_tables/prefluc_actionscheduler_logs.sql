/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_actionscheduler_logs`; */
/* PRE_TABLE_NAME: `1715196133_prefluc_actionscheduler_logs`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715196133_prefluc_actionscheduler_logs` ( `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `action_id` bigint(20) unsigned NOT NULL, `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL, `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00', `log_date_local` datetime DEFAULT '0000-00-00 00:00:00', PRIMARY KEY (`log_id`), KEY `action_id` (`action_id`), KEY `log_date_gmt` (`log_date_gmt`)) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1715196133_prefluc_actionscheduler_logs` (`log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES (1,118,'action created','2024-05-06 20:01:37','2024-05-06 22:01:37');
