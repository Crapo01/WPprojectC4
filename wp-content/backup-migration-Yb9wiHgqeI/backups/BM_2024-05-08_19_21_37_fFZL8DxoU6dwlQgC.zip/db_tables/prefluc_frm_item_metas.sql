/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_frm_item_metas`; */
/* PRE_TABLE_NAME: `1715196133_prefluc_frm_item_metas`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715196133_prefluc_frm_item_metas` ( `id` bigint(20) NOT NULL AUTO_INCREMENT, `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `field_id` bigint(20) NOT NULL, `item_id` bigint(20) NOT NULL, `created_at` datetime NOT NULL, PRIMARY KEY (`id`), KEY `field_id` (`field_id`), KEY `item_id` (`item_id`), KEY `idx_field_id_item_id` (`field_id`,`item_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
