/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_term_taxonomy`; */
/* PRE_TABLE_NAME: `1715196133_prefluc_term_taxonomy`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715196133_prefluc_term_taxonomy` ( `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `term_id` bigint(20) unsigned NOT NULL DEFAULT 0, `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL, `parent` bigint(20) unsigned NOT NULL DEFAULT 0, `count` bigint(20) NOT NULL DEFAULT 0, PRIMARY KEY (`term_taxonomy_id`), UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`), KEY `taxonomy` (`taxonomy`)) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1715196133_prefluc_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES (1,1,'category','',0,0),(2,2,'nav_menu','',0,7),(3,3,'nav_menu','',0,4),(4,4,'elementor_library_type','',0,2),(5,5,'elementor_library_type','',0,0),(6,6,'elementor_library_type','',0,1),(7,7,'category','',0,1),(8,8,'category','',0,2),(9,9,'category','',0,0);
