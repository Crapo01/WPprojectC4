/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_yoast_primary_term`; */
/* PRE_TABLE_NAME: `1715249197_prefluc_yoast_primary_term`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715249197_prefluc_yoast_primary_term` ( `id` int(11) unsigned NOT NULL AUTO_INCREMENT, `post_id` bigint(20) DEFAULT NULL, `term_id` bigint(20) DEFAULT NULL, `taxonomy` varchar(32) NOT NULL, `created_at` datetime DEFAULT NULL, `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(), `blog_id` bigint(20) NOT NULL DEFAULT 1, PRIMARY KEY (`id`), KEY `post_taxonomy` (`post_id`,`taxonomy`), KEY `post_term` (`post_id`,`term_id`)) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1715249197_prefluc_yoast_primary_term` (`id`, `post_id`, `term_id`, `taxonomy`, `created_at`, `updated_at`, `blog_id`) VALUES (1,51,1,'category','2024-05-05 16:17:31','2024-05-05 16:19:38',1),(2,60,7,'category','2024-05-05 16:31:59','2024-05-09 09:44:12',1),(3,81,7,'category','2024-05-05 17:00:29','2024-05-09 09:43:15',1),(4,126,9,'category','2024-05-09 09:51:24','2024-05-09 09:54:30',1),(5,118,7,'category','2024-05-09 09:55:05','2024-05-09 09:55:05',1);
