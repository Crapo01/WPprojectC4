/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_wpgmza_point_labels`; */
/* PRE_TABLE_NAME: `1715277285_prefluc_wpgmza_point_labels`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715277285_prefluc_wpgmza_point_labels` ( `id` int(11) NOT NULL AUTO_INCREMENT, `map_id` int(11) NOT NULL, `name` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `center` point DEFAULT NULL, `fillColor` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `lineColor` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `opacity` float DEFAULT NULL, `fontSize` varchar(3) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
