/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpbw_yoast_primary_term`; */
/* PRE_TABLE_NAME: `1715277285_wpbw_yoast_primary_term`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715277285_wpbw_yoast_primary_term` ( `id` int(11) unsigned NOT NULL AUTO_INCREMENT, `post_id` bigint(20) DEFAULT NULL, `term_id` bigint(20) DEFAULT NULL, `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL, `created_at` datetime DEFAULT NULL, `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(), `blog_id` bigint(20) NOT NULL DEFAULT 1, PRIMARY KEY (`id`), KEY `post_taxonomy` (`post_id`,`taxonomy`), KEY `post_term` (`post_id`,`term_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
