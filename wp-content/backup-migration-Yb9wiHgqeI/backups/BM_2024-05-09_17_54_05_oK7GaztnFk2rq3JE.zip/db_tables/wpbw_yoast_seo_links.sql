/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpbw_yoast_seo_links`; */
/* PRE_TABLE_NAME: `1715277285_wpbw_yoast_seo_links`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715277285_wpbw_yoast_seo_links` ( `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `url` varchar(255) DEFAULT NULL, `post_id` bigint(20) unsigned DEFAULT NULL, `target_post_id` bigint(20) unsigned DEFAULT NULL, `type` varchar(8) DEFAULT NULL, `indexable_id` int(11) unsigned DEFAULT NULL, `target_indexable_id` int(11) unsigned DEFAULT NULL, `height` int(11) unsigned DEFAULT NULL, `width` int(11) unsigned DEFAULT NULL, `size` int(11) unsigned DEFAULT NULL, `language` varchar(32) DEFAULT NULL, `region` varchar(32) DEFAULT NULL, PRIMARY KEY (`id`), KEY `link_direction` (`post_id`,`type`), KEY `indexable_link_direction` (`indexable_id`,`type`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
