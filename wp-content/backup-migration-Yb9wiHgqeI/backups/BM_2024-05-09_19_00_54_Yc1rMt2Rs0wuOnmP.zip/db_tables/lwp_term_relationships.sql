/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `lwp_term_relationships`; */
/* PRE_TABLE_NAME: `1715281296_lwp_term_relationships`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715281296_lwp_term_relationships` ( `object_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_order` int(11) NOT NULL DEFAULT 0, PRIMARY KEY (`object_id`,`term_taxonomy_id`), KEY `term_taxonomy_id` (`term_taxonomy_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1715281296_lwp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES (1,1,0);
