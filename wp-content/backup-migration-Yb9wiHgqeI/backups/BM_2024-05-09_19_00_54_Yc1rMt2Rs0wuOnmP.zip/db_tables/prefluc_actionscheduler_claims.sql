/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_actionscheduler_claims`; */
/* PRE_TABLE_NAME: `1715281296_prefluc_actionscheduler_claims`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715281296_prefluc_actionscheduler_claims` ( `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00', PRIMARY KEY (`claim_id`), KEY `date_created_gmt` (`date_created_gmt`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
