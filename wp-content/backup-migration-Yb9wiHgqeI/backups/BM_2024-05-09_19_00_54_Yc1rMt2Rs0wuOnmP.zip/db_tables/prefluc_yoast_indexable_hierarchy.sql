/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `prefluc_yoast_indexable_hierarchy`; */
/* PRE_TABLE_NAME: `1715281296_prefluc_yoast_indexable_hierarchy`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715281296_prefluc_yoast_indexable_hierarchy` ( `indexable_id` int(11) unsigned NOT NULL, `ancestor_id` int(11) unsigned NOT NULL, `depth` int(11) unsigned DEFAULT NULL, `blog_id` bigint(20) NOT NULL DEFAULT 1, PRIMARY KEY (`indexable_id`,`ancestor_id`), KEY `indexable_id` (`indexable_id`), KEY `ancestor_id` (`ancestor_id`), KEY `depth` (`depth`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1715281296_prefluc_yoast_indexable_hierarchy` (`indexable_id`, `ancestor_id`, `depth`, `blog_id`) VALUES (1,0,0,1),(3,0,0,1),(4,0,0,1),(5,0,0,1),(6,0,0,1),(7,0,0,1),(11,0,0,1),(12,0,0,1),(13,0,0,1),(14,0,0,1),(15,0,0,1),(16,0,0,1),(17,0,0,1),(18,0,0,1),(19,0,0,1),(20,0,0,1),(21,0,0,1),(22,0,0,1),(23,0,0,1),(24,0,0,1),(25,0,0,1),(26,0,0,1),(27,0,0,1),(29,0,0,1),(30,0,0,1),(31,0,0,1),(32,0,0,1),(33,0,0,1),(34,0,0,1),(35,0,0,1),(36,0,0,1),(37,0,0,1),(38,0,0,1),(39,0,0,1),(40,0,0,1),(41,0,0,1),(42,0,0,1),(43,0,0,1),(44,0,0,1),(45,0,0,1),(46,0,0,1),(47,0,0,1),(48,0,0,1),(49,0,0,1),(50,0,0,1),(51,0,0,1),(52,0,0,1),(53,0,0,1),(54,0,0,1),(55,0,0,1);
