/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpbw_yoast_indexable_hierarchy`; */
/* PRE_TABLE_NAME: `1715281296_wpbw_yoast_indexable_hierarchy`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1715281296_wpbw_yoast_indexable_hierarchy` ( `indexable_id` int(11) unsigned NOT NULL, `ancestor_id` int(11) unsigned NOT NULL, `depth` int(11) unsigned DEFAULT NULL, `blog_id` bigint(20) NOT NULL DEFAULT 1, PRIMARY KEY (`indexable_id`,`ancestor_id`), KEY `indexable_id` (`indexable_id`), KEY `ancestor_id` (`ancestor_id`), KEY `depth` (`depth`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
